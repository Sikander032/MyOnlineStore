<!DOCTYPE html>
<html lang="en">
@include('header')
<!-- Body-->
<body class="handheld-toolbar-enabled">
<!-- Google Tag Manager (noscript)-->
<noscript>
    <iframe src="//www.googletagmanager.com/ns.html?id=GTM-WKV3GT5" height="0" width="0" style="display: none; visibility: hidden;"></iframe>
</noscript>

<div>
    @yield('content')
</div>
@include('footer')

</body>
</html>
