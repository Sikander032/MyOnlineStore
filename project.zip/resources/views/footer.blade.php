<!-- Vendor scrits: js libraries and plugins-->

<script src="{{asset('vendor/bootstrap/dist/js/bootstrap.bundle.min.js')}}"></script>
<script src="{{asset('vendor/simplebar/dist/simplebar.min.js')}}"></script>
<script src="{{asset('vendor/tiny-slider/dist/min/tiny-slider.js')}}"></script>
<script src="{{asset('vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js')}}"></script>
<script src="{{asset('vendor/drift-zoom/dist/Drift.min.js')}}"></script>
<!-- Main theme script-->
<script src={{asset('assets/js/theme.min.js')}}></script>
