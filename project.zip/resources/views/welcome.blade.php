@extends('layouts.app')

@section('content')
    <div id="app">
        <app></app>
    </div>
    <script src="{{ mix('js/app.js') }}"></script>
@endsection
