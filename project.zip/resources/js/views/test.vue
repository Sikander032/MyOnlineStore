<template>
<div>
    hello
</div>
</template>

<script>
export default {
    name: "test.vue",
    created() {
        this.showToastr();
    },
    methods:{
        showToastr: function () {

        }
    }
}
</script>

<style scoped>

</style>
