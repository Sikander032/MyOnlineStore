<template>
    <!-- Shop by brand-->
    <section class="container py-lg-4 mb-4">
        <h2 class="h3 text-center pb-4">Shop by brand</h2>
        <div class="row">
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/01_adidas.png" style="width: 150px;" alt="Brand"></a></div>
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/02_puma.png" style="width: 150px;" alt="Brand"></a></div>
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/04_columbia.png" style="width: 150px;" alt="Brand"></a></div>
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/05_nike.png" style="width: 150px;" alt="Brand"></a></div>
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/06_hermes.png" style="width: 150px;" alt="Brand"></a></div>
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/07_brooks.png" style="width: 150px;" alt="Brand"></a></div>
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/08_eagle.png" style="width: 150px;" alt="Brand"></a></div>
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/09_nb.png" style="width: 150px;" alt="Brand"></a></div>
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/10_fila.png" style="width: 150px;" alt="Brand"></a></div>
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/11_dior.png" style="width: 150px;" alt="Brand"></a></div>
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/12ray_ban.png" style="width: 150px;" alt="Brand"></a></div>
            <div class="col-md-3 col-sm-4 col-6"><a class="d-block bg-white shadow-sm rounded-3 py-3 py-sm-4 mb-grid-gutter" href="#"><img class="d-block mx-auto" src="assets/images/03_tommy_hilfiger.png" style="width: 150px;" alt="Brand"></a></div>
        </div>
    </section>
</template>

<script>
export default {
    name: "brands.vue"
}
</script>

<style scoped>

</style>
