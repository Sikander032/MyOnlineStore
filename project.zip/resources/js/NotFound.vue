<template>
<div class="text-center">
    <div style="text-align: center;">Oops, Not Found.</div>
</div>
</template>

<script>
export default {
    name: "NotFound"
}
</script>

<style scoped>

</style>
