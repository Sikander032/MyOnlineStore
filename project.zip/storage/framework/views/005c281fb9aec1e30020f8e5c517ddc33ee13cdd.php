<!-- Vendor scrits: js libraries and plugins-->

<script src="<?php echo e(asset('vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/simplebar/dist/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/tiny-slider/dist/min/tiny-slider.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/drift-zoom/dist/Drift.min.js')); ?>"></script>
<!-- Main theme script-->
<script src=<?php echo e(asset('assets/js/theme.min.js')); ?>></script>
<?php /**PATH D:\xampp\htdocs\myonlinestore\resources\views/footer.blade.php ENDPATH**/ ?>