<?php

namespace App\Http\Controllers\Api;

class UserLoginException
{

    /**
     * @param string $string
     */
    public function __construct(string $string)
    {
    }
}
